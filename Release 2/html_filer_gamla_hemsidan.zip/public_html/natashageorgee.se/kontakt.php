<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://use.fontawesome.com/f185a80b16.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Bree+Serif|Open+Sans|Oswald" rel="stylesheet">
  <title></title>
<link rel="stylesheet" href="stylesheet.css" />
<meta charset="utf-8" />
</head>
<body>
<div class="wrapper">
<nav class="meny">
<div class="inre-kontainter">
<ul>
  <li><a href="#">HEM</a></li>
  <li><a href="cv.html">CV</a></li>
  <li><a href="portfolio.html">PORTFOLIO</a></li>
  <li><a href="kontakt.html">KONTAKTA MIG</a></li>
</ul>
<figure id="burger"> <i class="fa fa-bars" aria-hidden="true"></i></figure>
</div>
</nav>
<!--Meny två-->

<nav class="mobilemenu">
<div class="inre-kontainter">
<ul>
  <li><a href="#">HEM</a></li>
  <li><a href="cv.html">CV</a></li>
  <li><a href="portfolio.html">PORTFOLIO</a></li>
  <li><a href="kontakt.html">KONTAKTA MIG</a></li>
</ul>
</div>
</nav>
<!--Menu two ends here-->
</body>
</html>
