<?php
$db = mysqli_connect("10.209.2.40", "219313_ml53506", "natta13579", "CV");
mysqli_query($db,"SET NAMES utf8");
