<nav class="sidebar">
  <ul class="sidebar-list">
      <li class="sidebar-item">
        <a href="index.php" class="sidebar-anchor">HEM</a>
      </li>
      <li class="sidebar-item">
        <a href="cv.php" class="sidebar-anchor">CV</a>
      </li>
      <li class="sidebar-item">
        <a href="portfolio.php" class="sidebar-anchor">PORTFOLIO</a>
      </li>
      <li class="sidebar-item">
        <a href="kontakt.php" class="sidebar-anchor">KONTAKTA MIG</a>
      </li>
    </ul>
  </nav>
